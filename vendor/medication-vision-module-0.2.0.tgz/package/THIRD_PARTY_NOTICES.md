# 第三方依赖与研究参考台账

访问日期：2026-08-31

新增分发：Google MediaPipe MobileNetV3-small FLOAT32 v1 权重。该文件内嵌 `TFLITE_METADATA` 声明 Apache-2.0，SHA-256 与来源见 [整合记录](docs/INTEGRATION_2026-08-31.md)。完整许可证存于 Android assets 的 `medication_vision/LICENSE-MODEL.txt`。权重未修改；药片阈值尚未批准。

本项目自身为私有 `UNLICENSED` 代码。下表不改变任何第三方项目、模型或数据的原许可证。

## 运行时直接采用

| 项目 | 用途 | 许可证与边界 |
| --- | --- | --- |
| [Google LiteRT](https://github.com/google-ai-edge/LiteRT) | Android 端侧 CPU 推理 | Apache-2.0；固定 2.2.0。只采用 APK 内置运行库，不采用 Play Services 版本。 |
| [Expo Modules API](https://docs.expo.dev/modules/overview/) | TypeScript/Kotlin 原生模块桥接 | 依照 Expo 发布包许可证使用。 |

## 训练或实现参考，不进入 APK

| 项目 | 参考内容 | 使用限制 |
| --- | --- | --- |
| [LiteRT Samples](https://github.com/google-ai-edge/litert-samples) | 模型加载、缓冲区和生命周期 | 只参考实现模式。 |
| [PyTorch Metric Learning](https://github.com/KevinMusgrave/pytorch-metric-learning) | 后续隔离训练工程的度量学习 | MIT；不作为 Android 运行时依赖。 |
| [MediaPipe Image Embedder Android 示例](https://github.com/google-ai-edge/mediapipe-samples/tree/main/examples/image_embedder/android) | 图像嵌入、余弦比较和生命周期 | 只作设计参考。 |
| [ePillID Benchmark](https://github.com/usuyama/ePillID-benchmark) | 正反面基线、消费者照片和检索评测 | 代码许可与数据权利分开；数据不进入产品数据集。 |
| [MEDISEG](https://github.com/williamcwi/MEDISEG) | 遮挡、杂乱背景和实例分割评测 | 模型和原图权利需另行核验。 |
| [OpenCV](https://github.com/opencv/opencv) | 未来自然背景分割备选 | 当前不引入；需先评估包体、ABI 和 16KB 页面兼容。 |
| [react-native-fast-tflite](https://github.com/margelo/react-native-fast-tflite) | 性能对照 | 不作为正式桥接依赖。 |

## 明确排除

- Ultralytics Medical Pills：AGPL-3.0，且不提供个人基线闭集比较。
- PillNet、Few-shot Pill Recognition 等无明确许可证、模型或数据权利不清的项目。
- 已归档的 TensorFlow Similarity 和旧 React Native TFLite 桥接库。
- 依赖云端上传患者信息或直接输出开放式药品身份结论的实现。

任何新增模型、数据、转换工具或运行时必须在进入仓库和 APK 前补充来源、版本、许可证、SHA-256、用途、限制和审批人。
