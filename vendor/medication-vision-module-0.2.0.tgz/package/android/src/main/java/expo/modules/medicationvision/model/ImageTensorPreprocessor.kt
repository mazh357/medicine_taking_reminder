package expo.modules.medicationvision.model

import expo.modules.medicationvision.image.LocalImageDecoder
import expo.modules.medicationvision.core.NormalizedBox

internal class ImageTensorPreprocessor(private val decoder: LocalImageDecoder) {
  fun preprocess(localUri: String, box: NormalizedBox, manifest: ModelManifest): FloatArray {
    val height = manifest.input.shape[1]
    val width = manifest.input.shape[2]
    val bitmap = decoder.decodeObjectCrop(localUri, box, width, height)
    val pixels = IntArray(width * height)
    try {
      bitmap.getPixels(pixels, 0, width, 0, 0, width, height)
      val output = FloatArray(width * height * 3)
      var outputIndex = 0
      pixels.forEach { color ->
        val channels = intArrayOf(color ushr 16 and 0xff, color ushr 8 and 0xff, color and 0xff)
        for (channel in 0..2) {
          val normalized =
            (channels[channel] / 255.0 - manifest.normalization.mean[channel]) /
              manifest.normalization.standardDeviation[channel]
          output[outputIndex++] = normalized.toFloat()
        }
      }
      return output
    } finally {
      pixels.fill(0)
      if (!bitmap.isRecycled) bitmap.recycle()
    }
  }
}
