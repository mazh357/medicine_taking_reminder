package expo.modules.medicationvision.core

internal const val VISION_SCHEMA_VERSION = "1"
internal const val LITERT_RUNTIME_VERSION = "2.2.0"
internal const val ANALYSIS_TIMEOUT_MS = 3_000L

internal data class LocalImage(val photoEvidenceId: String, val localUri: String)

internal data class ReferenceImage(
  val photoEvidenceId: String,
  val localUri: String,
  val view: String
)

internal data class VisionCandidate(
  val localCandidateId: String,
  val baselineVersionId: String,
  val references: List<ReferenceImage>
)

internal data class VisionInput(
  val requestId: String,
  val mode: String,
  val currentImage: LocalImage,
  val candidates: List<VisionCandidate>
)

internal data class NormalizedBox(
  val x: Double,
  val y: Double,
  val width: Double,
  val height: Double
)

internal data class QualityObservation(val status: String, val issues: List<String>)

internal sealed interface CountObservation {
  data class Counted(
    val detectedObjectCount: Int,
    val boxes: List<NormalizedBox>
  ) : CountObservation

  data class Unable(val reason: String) : CountObservation
}

internal sealed interface AppearanceObservation {
  data class Assessed(val candidates: List<CandidateAppearance>, val objects: List<ObjectAppearance> = emptyList()) : AppearanceObservation
  data class Unable(val reason: String) : AppearanceObservation
}

internal data class ObjectAppearance(val objectIndex: Int, val box: NormalizedBox, val observation: CandidateAppearance)

internal sealed interface CandidateAppearance {
  val localCandidateId: String
  val baselineVersionId: String

  data class Observed(
    override val localCandidateId: String,
    override val baselineVersionId: String,
    val outcome: String,
    val distance: Double
  ) : CandidateAppearance

  data class Unable(
    override val localCandidateId: String,
    override val baselineVersionId: String,
    val reason: String
  ) : CandidateAppearance
}

internal data class VisionCapability(
  val available: Boolean,
  val tier: String,
  val modelVersion: String? = null,
  val supportsBaselineComparison: Boolean,
  val supportsGroupCandidates: Boolean,
  val reason: String
)

internal data class VisionResult(
  val requestId: String,
  val capabilityTier: String,
  val modelVersion: String? = null,
  val durationMs: Long,
  val quality: QualityObservation,
  val count: CountObservation,
  val appearance: AppearanceObservation
)

internal fun VisionCapability.toBridgeMap(): Map<String, Any> = buildMap {
  put("available", available)
  put("providerKind", "on_device")
  put("tier", tier)
  put("runtimeVersion", LITERT_RUNTIME_VERSION)
  modelVersion?.let { put("modelVersion", it) }
  put("supportsBaselineComparison", supportsBaselineComparison)
  put("supportsGroupCandidates", supportsGroupCandidates)
  put("reason", reason)
}

internal fun VisionResult.toBridgeMap(): Map<String, Any> = buildMap {
  put("schemaVersion", VISION_SCHEMA_VERSION)
  put("requestId", requestId)
  put("providerKind", "on_device")
  put("capabilityTier", capabilityTier)
  put("runtimeVersion", LITERT_RUNTIME_VERSION)
  modelVersion?.let { put("modelVersion", it) }
  put("durationMs", durationMs)
  put("quality", mapOf("status" to quality.status, "issues" to quality.issues))
  put("objects", (appearance as? AppearanceObservation.Assessed)?.objects?.map { item ->
    val observation = item.observation
    val fields = mutableMapOf<String, Any>("localCandidateId" to observation.localCandidateId, "baselineVersionId" to observation.baselineVersionId)
    when (observation) {
      is CandidateAppearance.Observed -> { fields["outcome"] = observation.outcome; fields["distance"] = observation.distance }
      is CandidateAppearance.Unable -> { fields["outcome"] = "unable"; fields["reason"] = observation.reason }
    }
    mapOf("objectIndex" to item.objectIndex, "box" to mapOf("x" to item.box.x, "y" to item.box.y, "width" to item.box.width, "height" to item.box.height), "observation" to fields)
  } ?: emptyList<Map<String, Any>>())
  put(
    "count",
    when (val observation = count) {
      is CountObservation.Counted -> mapOf(
        "status" to "counted",
        "detectedObjectCount" to observation.detectedObjectCount,
        "boxes" to observation.boxes.map { box ->
          mapOf("x" to box.x, "y" to box.y, "width" to box.width, "height" to box.height)
        }
      )
      is CountObservation.Unable -> mapOf("status" to "unable", "reason" to observation.reason)
    }
  )
  put(
    "appearance",
    when (val observation = appearance) {
      is AppearanceObservation.Assessed -> mapOf(
        "status" to "assessed",
        "candidates" to observation.candidates.map { candidate ->
          when (candidate) {
            is CandidateAppearance.Observed -> mapOf(
              "localCandidateId" to candidate.localCandidateId,
              "baselineVersionId" to candidate.baselineVersionId,
              "outcome" to candidate.outcome,
              "distance" to candidate.distance
            )
            is CandidateAppearance.Unable -> mapOf(
              "localCandidateId" to candidate.localCandidateId,
              "baselineVersionId" to candidate.baselineVersionId,
              "outcome" to "unable",
              "reason" to candidate.reason
            )
          }
        }
      )
      is AppearanceObservation.Unable -> mapOf("status" to "unable", "reason" to observation.reason)
    }
  )
}
