package expo.modules.medicationvision.model;

import android.content.res.AssetManager;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * Java-only boundary around LiteRT 2.2.
 *
 * LiteRT 2.2 is published with Kotlin 2.3 metadata while Expo SDK 57 uses Kotlin 2.1.
 * Keeping every LiteRT type behind this Java class lets the module retain the supported
 * Expo Kotlin toolchain without disabling Kotlin metadata checks.
 */
final class LiteRtCompiledModelBridge implements AutoCloseable {
  private static final String COMPILED_MODEL = "com.google.ai.edge.litert.CompiledModel";
  private static final String OPTIONS = "com.google.ai.edge.litert.CompiledModel$Options";

  private final Object model;
  private final Class<?> modelClass;

  private LiteRtCompiledModelBridge(Object model, Class<?> modelClass) {
    this.model = model;
    this.modelClass = modelClass;
  }

  static LiteRtCompiledModelBridge create(AssetManager assets, String modelAsset) throws Exception {
    Class<?> modelClass = Class.forName(COMPILED_MODEL);
    Class<?> optionsClass = Class.forName(OPTIONS);
    Object cpuOptions = optionsClass.getMethod("getCPU").invoke(null);
    Object model = modelClass
      .getMethod("create", AssetManager.class, String.class, optionsClass)
      .invoke(null, assets, modelAsset, cpuOptions);
    return new LiteRtCompiledModelBridge(model, modelClass);
  }

  TensorDescription inputDescription(String tensorName, String signature) throws Exception {
    return describe(invoke(model, "getInputTensorType", tensorName, signature));
  }

  TensorDescription outputDescription(String tensorName, String signature) throws Exception {
    return describe(invoke(model, "getOutputTensorType", tensorName, signature));
  }

  float[] run(
    String inputName,
    String outputName,
    String signature,
    float[] inputValues
  ) throws Exception {
    Object input = null;
    Object output = null;
    try {
      input = invoke(model, "createInputBuffer", inputName, signature);
      output = invoke(model, "createOutputBuffer", outputName, signature);
      invoke(input, "writeFloat", inputValues);
      invokeRun(
        Collections.singletonMap(inputName, input),
        Collections.singletonMap(outputName, output),
        signature
      );
      return (float[]) invoke(output, "readFloat");
    } finally {
      closeQuietly(input);
      closeQuietly(output);
    }
  }

  @SuppressWarnings("unchecked")
  private static TensorDescription describe(Object tensorType) throws Exception {
    Object elementType = invoke(tensorType, "getElementType");
    Object layout = invoke(tensorType, "getLayout");
    List<Integer> dimensions = layout == null
      ? Collections.emptyList()
      : (List<Integer>) invoke(layout, "getDimensions");
    return new TensorDescription(((Enum<?>) elementType).name(), dimensions);
  }

  private void invokeRun(
    Map<String, Object> inputs,
    Map<String, Object> outputs,
    String signature
  ) throws Exception {
    Method run = modelClass.getMethod("run", Map.class, Map.class, String.class);
    invokeMethod(run, model, inputs, outputs, signature);
  }

  private static Object invoke(Object target, String methodName, Object... arguments) throws Exception {
    Method match = null;
    for (Method method : target.getClass().getMethods()) {
      if (method.getName().equals(methodName) && method.getParameterCount() == arguments.length) {
        boolean compatible = true;
        Class<?>[] types = method.getParameterTypes();
        for (int i = 0; i < types.length; i++) {
          if (arguments[i] != null && !types[i].isInstance(arguments[i])) compatible = false;
        }
        if (!compatible) continue;
        if (match != null) throw new NoSuchMethodException("Ambiguous overload: " + methodName);
        match = method;
      }
    }
    if (match == null) {
      throw new NoSuchMethodException(target.getClass().getName() + "." + methodName);
    }
    return invokeMethod(match, target, arguments);
  }

  private static Object invokeMethod(Method method, Object target, Object... arguments) throws Exception {
    try {
      return method.invoke(target, arguments);
    } catch (InvocationTargetException error) {
      Throwable cause = error.getCause();
      if (cause instanceof Exception) throw (Exception) cause;
      if (cause instanceof Error) throw (Error) cause;
      throw error;
    }
  }

  private static void closeQuietly(Object value) {
    if (value == null) return;
    try {
      invoke(value, "close");
    } catch (Throwable ignored) {
      // A failed buffer cleanup must not mask the original inference failure.
    }
  }

  @Override
  public void close() {
    closeQuietly(model);
  }

  static final class TensorDescription {
    private final String elementType;
    private final List<Integer> dimensions;

    TensorDescription(String elementType, List<Integer> dimensions) {
      this.elementType = elementType;
      this.dimensions = List.copyOf(dimensions);
    }

    String getElementType() {
      return elementType;
    }

    List<Integer> getDimensions() {
      return dimensions;
    }
  }
}
