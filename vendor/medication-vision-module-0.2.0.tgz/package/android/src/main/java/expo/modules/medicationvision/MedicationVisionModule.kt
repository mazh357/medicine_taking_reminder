package expo.modules.medicationvision

import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition
import expo.modules.medicationvision.core.DefaultVisionEngine
import expo.modules.medicationvision.core.VisionCoordinator
import expo.modules.medicationvision.core.VisionJsonCodec
import expo.modules.medicationvision.core.toBridgeMap

class MedicationVisionModule : Module() {
  @Volatile private var coordinator: VisionCoordinator? = null
  @Volatile private var foreground = true

  override fun definition() = ModuleDefinition {
    Name("MedicationVision")

    AsyncFunction("getCapabilityAsync") {
      getCoordinator().capability().toBridgeMap()
    }

    AsyncFunction("analyzeAsync") { inputJson: String ->
      val input = VisionJsonCodec.decodeInput(inputJson)
      getCoordinator().analyze(input).toBridgeMap()
    }

    AsyncFunction("cancelAsync") { coordinator?.close() }
    OnActivityEntersBackground { foreground = false; coordinator?.close() }
    OnActivityEntersForeground { foreground = true }

    OnDestroy {
      coordinator?.close()
      // Retain quarantine until process restart; never overlap a timed-out native call.
    }
  }

  @Synchronized
  private fun getCoordinator(): VisionCoordinator {
    coordinator?.let { if (!it.released || !foreground) return it }
    check(foreground) { "Vision is unavailable in background" }
    val context = requireNotNull(appContext.reactContext) { "Android context is unavailable" }
    return VisionCoordinator(DefaultVisionEngine(context.applicationContext)).also { coordinator = it }
  }
}
