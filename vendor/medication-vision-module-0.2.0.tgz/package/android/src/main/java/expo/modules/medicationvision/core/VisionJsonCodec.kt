package expo.modules.medicationvision.core

import org.json.JSONArray
import org.json.JSONObject

internal object VisionJsonCodec {
  fun decodeInput(json: String): VisionInput {
    val root = JSONObject(json)
    if (root.getString("schemaVersion") != VISION_SCHEMA_VERSION) {
      throw VisionContractException("Unsupported schema version")
    }
    val current = root.getJSONObject("currentImage")
    val candidates = root.getJSONArray("candidates").mapObjects { candidate ->
      VisionCandidate(
        localCandidateId = candidate.getString("localCandidateId"),
        baselineVersionId = candidate.getString("baselineVersionId"),
        references = candidate.getJSONArray("references").mapObjects { reference ->
          ReferenceImage(
            photoEvidenceId = reference.getString("photoEvidenceId"),
            localUri = reference.getString("localUri"),
            view = reference.getString("view")
          )
        }
      )
    }
    return VisionInputValidator.validate(
      VisionInput(
        requestId = root.getString("requestId"),
        mode = root.getString("mode"),
        currentImage = LocalImage(
          photoEvidenceId = current.getString("photoEvidenceId"),
          localUri = current.getString("localUri")
        ),
        candidates = candidates
      )
    )
  }

  private inline fun <T> JSONArray.mapObjects(transform: (JSONObject) -> T): List<T> =
    List(length()) { index -> transform(getJSONObject(index)) }
}
