package expo.modules.medicationvision.core

import android.content.Context
import expo.modules.medicationvision.count.ControlledBackgroundCounter
import expo.modules.medicationvision.count.CounterResult
import expo.modules.medicationvision.image.LocalImageDecoder
import expo.modules.medicationvision.model.AppearanceEngine
import expo.modules.medicationvision.model.LiteRtAppearanceEngine

internal interface VisionEngine : AutoCloseable {
  fun capability(): VisionCapability
  fun analyze(input: VisionInput): VisionResult
}

internal class DefaultVisionEngine(
  context: Context,
  private val appearanceEngine: AppearanceEngine = LiteRtAppearanceEngine(context)
) : VisionEngine {
  private val decoder = LocalImageDecoder(context)
  private val counter = ControlledBackgroundCounter()

  override fun capability(): VisionCapability {
    val appearance = appearanceEngine.capability()
    return VisionCapability(
      available = true,
      tier = if (appearance.available) "full" else "count_only",
      modelVersion = appearance.modelVersion,
      supportsBaselineComparison = appearance.available,
      supportsGroupCandidates = false,
      reason = appearance.reason
    )
  }

  override fun analyze(input: VisionInput): VisionResult {
    val capability = capability()
    val decoded = try {
      decoder.decodeForCount(input.currentImage.localUri)
    } catch (_: Throwable) {
      return VisionResult(
        requestId = input.requestId,
        capabilityTier = capability.tier,
        modelVersion = capability.modelVersion,
        durationMs = 0,
        quality = QualityObservation("unable", listOf("unsupported_image")),
        count = CountObservation.Unable("unsupported_image"),
        appearance = AppearanceObservation.Unable("quality_unacceptable")
      )
    }

    return try { when (val countResult = counter.count(decoded.frame)) {
      is CounterResult.Unable -> VisionResult(
        requestId = input.requestId,
        capabilityTier = capability.tier,
        modelVersion = capability.modelVersion,
        durationMs = 0,
        quality = QualityObservation("unable", listOf(countResult.reason.wireValue)),
        count = CountObservation.Unable(countResult.reason.wireValue),
        appearance = AppearanceObservation.Unable("quality_unacceptable")
      )
      is CounterResult.Counted -> {
        val boxes = countResult.boxes.map { box ->
          NormalizedBox(
            x = box.x.toDouble() / decoded.frame.width,
            y = box.y.toDouble() / decoded.frame.height,
            width = box.width.toDouble() / decoded.frame.width,
            height = box.height.toDouble() / decoded.frame.height
          )
        }
        if (boxes.size !in 1..8 || (input.mode == "baseline" && boxes.size != 1)) {
          return VisionResult(input.requestId, capability.tier, capability.modelVersion, 0,
            QualityObservation("unable", listOf("unsupported_image")), CountObservation.Unable("unsupported_image"), AppearanceObservation.Unable("quality_unacceptable"))
        }
        VisionResult(
          requestId = input.requestId,
          capabilityTier = capability.tier,
          modelVersion = capability.modelVersion,
          durationMs = 0,
          quality = QualityObservation("acceptable", emptyList()),
          count = CountObservation.Counted(boxes.size, boxes),
          appearance = if (capability.tier == "full" && input.mode != "baseline") {
            appearanceEngine.analyze(input, boxes)
          } else {
            AppearanceObservation.Unable(
              if (capability.reason == "thresholds_not_approved") {
                "thresholds_not_approved"
              } else {
                "model_unavailable"
              }
            )
          }
        )
      }
    } } finally { decoded.frame.pixels.fill(0) }
  }

  override fun close() {
    appearanceEngine.close()
  }
}
