package expo.modules.medicationvision.model

import android.content.Context
import expo.modules.medicationvision.core.AppearanceObservation
import expo.modules.medicationvision.core.CandidateAppearance
import expo.modules.medicationvision.core.VisionInput
import expo.modules.medicationvision.core.NormalizedBox
import expo.modules.medicationvision.core.ObjectAppearance
import expo.modules.medicationvision.count.ControlledBackgroundCounter
import expo.modules.medicationvision.count.CounterResult
import expo.modules.medicationvision.image.LocalImageDecoder
import java.io.FileNotFoundException
import java.security.MessageDigest
import kotlin.math.sqrt

internal interface AppearanceEngine : AutoCloseable {
  fun capability(): AppearanceEngineCapability
  fun analyze(input: VisionInput, boxes: List<NormalizedBox>): AppearanceObservation
}

internal data class AppearanceEngineCapability(
  val available: Boolean,
  val modelVersion: String? = null,
  val reason: String
)

/**
 * Generic FLOAT32 embedding runner. No model is shipped by this repository. A model becomes
 * usable only after its manifest, hash, tensor contract, and thresholds all pass preflight.
 */
internal class LiteRtAppearanceEngine(private val context: Context) : AppearanceEngine {
  private sealed interface Preparation {
    data class Ready(val manifest: ModelManifest, val model: LiteRtCompiledModelBridge) : Preparation
    data class Degraded(val reason: String, val modelVersion: String? = null) : Preparation
  }

  @Volatile private var preparation: Preparation? = null
  private val decoder = LocalImageDecoder(context)
  private val preprocessor = ImageTensorPreprocessor(decoder)

  override fun capability(): AppearanceEngineCapability = when (val state = prepare()) {
    is Preparation.Ready -> AppearanceEngineCapability(true, state.manifest.modelVersion, "ready")
    is Preparation.Degraded -> AppearanceEngineCapability(false, state.modelVersion, state.reason)
  }

  override fun analyze(input: VisionInput, boxes: List<NormalizedBox>): AppearanceObservation {
    if (input.mode == "group") return AppearanceObservation.Unable("group_not_supported")
    val state = prepare()
    if (state !is Preparation.Ready) {
      return AppearanceObservation.Unable(
        if (state is Preparation.Degraded && state.reason == "thresholds_not_approved") {
          "thresholds_not_approved"
        } else {
          "model_unavailable"
        }
      )
    }

    val candidate = input.candidates.single()
    val sensitive = mutableListOf<FloatArray>()
    return try {
      val references = candidate.references.map { reference ->
        val decoded = decoder.decodeForCount(reference.localUri)
        val box = try {
          val counted = ControlledBackgroundCounter().count(decoded.frame) as? CounterResult.Counted
            ?: return AppearanceObservation.Unable("reference_inconsistent")
          if (counted.boxes.size != 1) return AppearanceObservation.Unable("reference_inconsistent")
          val b = counted.boxes.single()
          NormalizedBox(b.x.toDouble() / decoded.frame.width, b.y.toDouble() / decoded.frame.height,
            b.width.toDouble() / decoded.frame.width, b.height.toDouble() / decoded.frame.height)
        } finally { decoded.frame.pixels.fill(0) }
        embed(reference.localUri, box, state).also { sensitive.add(it) }
      }
      val objects = boxes.mapIndexed { index, box ->
        val current = embed(input.currentImage.localUri, box, state).also { sensitive.add(it) }
        val distance = references.minOf { reference -> cosineDistance(current, reference) }
        ObjectAppearance(index, box, CandidateAppearance.Observed(candidate.localCandidateId,
          candidate.baselineVersionId,
          if (distance > state.manifest.thresholds.suspectedChangeDistance) "suspected_change" else "no_anomaly_signal", distance))
      }
      // Front and back can legitimately differ. Aggregate worst object, never compare the two sides to reject a baseline.
      val worst = objects.map { it.observation as CandidateAppearance.Observed }.maxBy { it.distance }
      AppearanceObservation.Assessed(listOf(worst), objects)
    } catch (_: Throwable) {
      AppearanceObservation.Unable("processing_error")
    } finally { sensitive.forEach { it.fill(0f) } }
  }

  @Synchronized
  private fun prepare(): Preparation {
    preparation?.let { return it }
    val parsedManifest = try {
      context.assets.open(MANIFEST_ASSET).bufferedReader().use { reader ->
        ModelManifestValidator.validate(ModelManifestParser.parse(reader.readText()))
      }
    } catch (_: FileNotFoundException) {
      return Preparation.Degraded("model_manifest_missing").also { preparation = it }
    } catch (_: Throwable) {
      return Preparation.Degraded("model_manifest_invalid").also { preparation = it }
    }
    if (!parsedManifest.distributionApproved || !parsedManifest.approvedForClosedSetUse || !parsedManifest.thresholdsApproved || parsedManifest.evaluationEvidence == null) {
      return Preparation.Degraded("thresholds_not_approved", parsedManifest.modelVersion).also {
        preparation = it
      }
    }

    val actualHash = try {
      context.assets.open(parsedManifest.modelAsset).use(::sha256)
    } catch (_: FileNotFoundException) {
      return Preparation.Degraded("model_missing", parsedManifest.modelVersion).also { preparation = it }
    } catch (_: Throwable) {
      return Preparation.Degraded("model_missing", parsedManifest.modelVersion).also { preparation = it }
    }
    if (actualHash != parsedManifest.sha256) {
      return Preparation.Degraded("model_hash_mismatch", parsedManifest.modelVersion).also { preparation = it }
    }

    val compiledModel = try {
      LiteRtCompiledModelBridge.create(context.assets, parsedManifest.modelAsset)
    } catch (_: Throwable) {
      return Preparation.Degraded("runtime_unavailable", parsedManifest.modelVersion).also { preparation = it }
    }
    return try {
      preflightTensor(compiledModel, parsedManifest.input, parsedManifest.signature, input = true)
      preflightTensor(compiledModel, parsedManifest.output, parsedManifest.signature, input = false)
      Preparation.Ready(parsedManifest, compiledModel).also { preparation = it }
    } catch (_: Throwable) {
      compiledModel.close()
      Preparation.Degraded("tensor_contract_mismatch", parsedManifest.modelVersion).also { preparation = it }
    }
  }

  private fun preflightTensor(
    model: LiteRtCompiledModelBridge,
    expected: TensorContract,
    signature: String,
    input: Boolean
  ) {
    val actual = if (input) {
      model.inputDescription(expected.name, signature)
    } else {
      model.outputDescription(expected.name, signature)
    }
    require(actual.elementType == "FLOAT") { "Tensor element type mismatch" }
    require(actual.dimensions == expected.shape) { "Tensor shape mismatch" }
  }

  private fun embed(localUri: String, box: NormalizedBox, state: Preparation.Ready): FloatArray {
    val values = preprocessor.preprocess(localUri, box, state.manifest)
    val embedding = try { state.model.run(
      state.manifest.input.name,
      state.manifest.output.name,
      state.manifest.signature,
      values
    ) } finally { values.fill(0f) }
    require(embedding.size == state.manifest.output.shape[1]) { "Embedding length mismatch" }
    require(embedding.all { it.isFinite() }) { "Embedding contains non-finite values" }
    return embedding
  }

  private fun cosineDistance(first: FloatArray, second: FloatArray): Double {
    require(first.size == second.size && first.isNotEmpty())
    var dot = 0.0
    var firstNorm = 0.0
    var secondNorm = 0.0
    for (index in first.indices) {
      val a = first[index].toDouble()
      val b = second[index].toDouble()
      require(a.isFinite() && b.isFinite())
      dot += a * b
      firstNorm += a * a
      secondNorm += b * b
    }
    require(firstNorm > 0.0 && secondNorm > 0.0)
    return (1.0 - dot / (sqrt(firstNorm) * sqrt(secondNorm))).coerceIn(0.0, 2.0)
  }

  override fun close() {
    val current = preparation
    if (current is Preparation.Ready) current.model.close()
    preparation = null
  }

  private fun sha256(input: java.io.InputStream): String {
    val digest = MessageDigest.getInstance("SHA-256")
    val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
    while (true) {
      val count = input.read(buffer)
      if (count < 0) break
      digest.update(buffer, 0, count)
    }
    return digest.digest().joinToString("") { byte -> "%02x".format(byte) }
  }

  private companion object {
    const val MANIFEST_ASSET = "medication_vision/model-manifest.json"
  }
}
