package expo.modules.medicationvision.image

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import expo.modules.medicationvision.count.CounterThresholds
import expo.modules.medicationvision.count.PixelFrame
import expo.modules.medicationvision.core.NormalizedBox
import java.io.File
import java.io.InputStream

internal data class DecodedCountImage(
  val frame: PixelFrame,
  val sourceWidth: Int,
  val sourceHeight: Int
)

/** Reads bounded local images. The host should pass app-private decrypted staging files. */
internal class LocalImageDecoder(private val context: Context) {
  fun decodeForCount(uriString: String): DecodedCountImage {
    val uri = validateUri(uriString)
    val bounds = readBounds(uri)
    val options = BitmapFactory.Options().apply {
      inSampleSize = sampleSize(bounds.first, bounds.second, CounterThresholds.MAX_DECODED_EDGE)
      inPreferredConfig = Bitmap.Config.ARGB_8888
    }
    val bitmap = decode(uri, options)
    try {
      val pixels = IntArray(bitmap.width * bitmap.height)
      bitmap.getPixels(pixels, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)
      return DecodedCountImage(
        frame = PixelFrame(bitmap.width, bitmap.height, pixels),
        sourceWidth = bounds.first,
        sourceHeight = bounds.second
      )
    } finally {
      bitmap.recycle()
    }
  }

  fun decodeObjectCrop(uriString: String, box: NormalizedBox, targetWidth: Int, targetHeight: Int): Bitmap {
    require(targetWidth in 64..1024 && targetHeight in 64..1024)
    val uri = validateUri(uriString)
    val bounds = readBounds(uri)
    val decodeEdge = maxOf(targetWidth, targetHeight) * 4
    val options = BitmapFactory.Options().apply {
      inSampleSize = sampleSize(bounds.first, bounds.second, decodeEdge)
      inPreferredConfig = Bitmap.Config.ARGB_8888
    }
    val source = decode(uri, options)
    var cropped: Bitmap? = null
    var scaled: Bitmap? = null
    try {
      val left = (box.x * source.width).toInt().coerceIn(0, source.width - 1)
      val top = (box.y * source.height).toInt().coerceIn(0, source.height - 1)
      val width = kotlin.math.ceil(box.width * source.width).toInt().coerceIn(1, source.width - left)
      val height = kotlin.math.ceil(box.height * source.height).toInt().coerceIn(1, source.height - top)
      cropped = Bitmap.createBitmap(source, left, top, width, height)
      scaled = Bitmap.createScaledBitmap(cropped, targetWidth, targetHeight, true)
      return scaled
    } finally {
      if (source !== scaled && !source.isRecycled) source.recycle()
      cropped?.let { if (it !== scaled && !it.isRecycled) it.recycle() }
    }
  }

  private fun validateUri(uriString: String): Uri {
    val uri = Uri.parse(uriString)
    require(uri.scheme == "file" || uri.scheme == "content") { "Only local image URIs are supported" }
    if (uri.scheme == "content") {
      val provider = context.packageManager.resolveContentProvider(requireNotNull(uri.authority), 0)
      require(provider?.applicationInfo?.uid == context.applicationInfo.uid) { "Only host-owned providers are accepted" }
    }
    if (uri.scheme == "file") {
      val path = requireNotNull(uri.path) { "File URI has no path" }
      val requested = File(path).canonicalFile
      val privateRoot = File(context.applicationInfo.dataDir).canonicalFile
      require(
        requested.path == privateRoot.path || requested.path.startsWith(privateRoot.path + File.separator)
      ) { "File URI is outside the application-private directory" }
    }
    return uri
  }

  private fun readBounds(uri: Uri): Pair<Int, Int> {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    open(uri).use { input -> BitmapFactory.decodeStream(input, null, bounds) }
    require(bounds.outWidth > 0 && bounds.outHeight > 0) { "Image dimensions are invalid" }
    require(bounds.outWidth <= MAX_SOURCE_EDGE && bounds.outHeight <= MAX_SOURCE_EDGE) {
      "Image dimensions exceed the safety limit"
    }
    require(bounds.outWidth.toLong() * bounds.outHeight <= MAX_SOURCE_PIXELS) {
      "Image pixel count exceeds the safety limit"
    }
    return bounds.outWidth to bounds.outHeight
  }

  private fun decode(uri: Uri, options: BitmapFactory.Options): Bitmap {
    val original = open(uri).use { requireNotNull(BitmapFactory.decodeStream(it, null, options)) }
    try {
      val orientation = open(uri).use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1) }
      val matrix = Matrix().apply {
        when (orientation) {
          2 -> setScale(-1f, 1f)
          3 -> setRotate(180f)
          4 -> setScale(1f, -1f)
          5 -> { setRotate(90f); postScale(-1f, 1f) }
          6 -> setRotate(90f)
          7 -> { setRotate(-90f); postScale(-1f, 1f) }
          8 -> setRotate(-90f)
        }
      }
      val oriented = Bitmap.createBitmap(original, 0, 0, original.width, original.height, matrix, true)
      if (oriented !== original) original.recycle()
      return oriented
    } catch (error: Throwable) { original.recycle(); throw error }
  }

  private fun open(uri: Uri): InputStream = requireNotNull(context.contentResolver.openInputStream(uri)) {
    "Unable to open image URI"
  }

  private fun sampleSize(width: Int, height: Int, maxEdge: Int): Int {
    var sample = 1
    while (maxOf(width, height) / sample > maxEdge) sample *= 2
    return sample
  }

  private companion object {
    const val MAX_SOURCE_EDGE = 20_000
    const val MAX_SOURCE_PIXELS = 60_000_000L
  }
}
