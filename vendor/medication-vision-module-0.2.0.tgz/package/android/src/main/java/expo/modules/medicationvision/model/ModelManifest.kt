package expo.modules.medicationvision.model

import expo.modules.medicationvision.core.LITERT_RUNTIME_VERSION
import org.json.JSONObject

internal data class TensorContract(
  val name: String,
  val shape: List<Int>,
  val elementType: String
)

internal data class NormalizationContract(
  val mean: List<Double>,
  val standardDeviation: List<Double>
)

internal data class AppearanceThresholds(
  val suspectedChangeDistance: Double,
  val maxReferenceSpread: Double
)

internal data class ModelManifest(
  val schemaVersion: String,
  val runtimeVersion: String,
  val modelVersion: String,
  val modelAsset: String,
  val sha256: String,
  val approvedForClosedSetUse: Boolean,
  val thresholdsApproved: Boolean,
  val signature: String,
  val input: TensorContract,
  val output: TensorContract,
  val normalization: NormalizationContract,
  val thresholds: AppearanceThresholds,
  val distributionApproved: Boolean = false,
  val evaluationEvidence: String? = null
)

internal object ModelManifestParser {
  fun parse(json: String): ModelManifest {
    val root = JSONObject(json)
    val input = root.getJSONObject("input")
    val output = root.getJSONObject("output")
    val normalization = root.getJSONObject("normalization")
    val thresholds = root.getJSONObject("thresholds")
    return ModelManifest(
      schemaVersion = root.getString("schemaVersion"),
      runtimeVersion = root.getString("runtimeVersion"),
      modelVersion = root.getString("modelVersion"),
      modelAsset = root.getString("modelAsset"),
      sha256 = root.getString("sha256").lowercase(),
      approvedForClosedSetUse = root.getBoolean("approvedForClosedSetUse"),
      thresholdsApproved = root.getBoolean("thresholdsApproved"),
      signature = root.optString("signature", ""),
      input = TensorContract(
        name = input.getString("name"),
        shape = input.getJSONArray("shape").toIntList(),
        elementType = input.getString("elementType")
      ),
      output = TensorContract(
        name = output.getString("name"),
        shape = output.getJSONArray("shape").toIntList(),
        elementType = output.getString("elementType")
      ),
      normalization = NormalizationContract(
        mean = normalization.getJSONArray("mean").toDoubleList(),
        standardDeviation = normalization.getJSONArray("standardDeviation").toDoubleList()
      ),
      thresholds = AppearanceThresholds(
        suspectedChangeDistance = thresholds.getDouble("suspectedChangeDistance"),
        maxReferenceSpread = thresholds.getDouble("maxReferenceSpread")
      ),
      distributionApproved = root.optBoolean("distributionApproved", false),
      evaluationEvidence = root.optString("evaluationEvidence", "").takeIf { it.isNotBlank() && it != "null" }
    )
  }

  private fun org.json.JSONArray.toIntList(): List<Int> = List(length()) { getInt(it) }
  private fun org.json.JSONArray.toDoubleList(): List<Double> = List(length()) { getDouble(it) }
}

internal object ModelManifestValidator {
  fun validate(manifest: ModelManifest): ModelManifest {
    require(manifest.schemaVersion == "1") { "Unsupported model manifest schema" }
    require(manifest.runtimeVersion == LITERT_RUNTIME_VERSION) { "LiteRT runtime version mismatch" }
    require(manifest.modelVersion.isNotBlank() && manifest.modelVersion.length <= 128) { "Invalid model version" }
    require(
      manifest.modelAsset.startsWith("medication_vision/") &&
        manifest.modelAsset.endsWith(".tflite") &&
        ".." !in manifest.modelAsset &&
        !manifest.modelAsset.startsWith("/")
    ) { "Invalid model asset path" }
    require(Regex("^[0-9a-f]{64}$").matches(manifest.sha256)) { "Invalid model SHA-256" }
    require(manifest.input.elementType == "FLOAT32") { "Only FLOAT32 input is supported" }
    require(manifest.output.elementType == "FLOAT32") { "Only FLOAT32 output is supported" }
    require(manifest.input.shape.size == 4) { "Input must be NHWC rank 4" }
    require(manifest.input.shape[0] == 1 && manifest.input.shape[3] == 3) { "Input must be [1,H,W,3]" }
    require(manifest.input.shape[1] in 64..1024 && manifest.input.shape[2] in 64..1024) {
      "Input dimensions exceed the approved range"
    }
    require(manifest.output.shape.size == 2 && manifest.output.shape[0] == 1) { "Output must be [1,N]" }
    require(manifest.output.shape[1] in 8..4096) { "Embedding width exceeds the approved range" }
    require(manifest.input.name.isNotBlank() && manifest.output.name.isNotBlank()) { "Tensor names are required" }
    require(manifest.normalization.mean.size == 3 && manifest.normalization.standardDeviation.size == 3) {
      "RGB normalization must contain three channels"
    }
    require(manifest.normalization.mean.all { it.isFinite() }) { "Normalization mean must be finite" }
    require(manifest.normalization.standardDeviation.all { it.isFinite() && it > 0.0 }) {
      "Normalization standard deviation must be finite and positive"
    }
    require(
      manifest.thresholds.suspectedChangeDistance.isFinite() &&
        manifest.thresholds.suspectedChangeDistance in 0.0..2.0
    ) { "Invalid suspected-change threshold" }
    require(
      manifest.thresholds.maxReferenceSpread.isFinite() &&
        manifest.thresholds.maxReferenceSpread in 0.0..2.0
    ) { "Invalid reference-spread threshold" }
    return manifest
  }
}
