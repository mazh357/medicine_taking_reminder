package expo.modules.medicationvision.core

import java.util.concurrent.Executors
import java.util.concurrent.ExecutorService
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException
import java.util.concurrent.atomic.AtomicBoolean

/** Every engine operation, including close, runs on one worker. */
internal class VisionCoordinator(
  private val engine: VisionEngine,
  private val timeoutMs: Long = ANALYSIS_TIMEOUT_MS,
  private val executor: ExecutorService = Executors.newSingleThreadExecutor { task ->
    Thread(task, "medication-vision-serial").apply { isDaemon = true }
  }
) : AutoCloseable {
  private val closed = AtomicBoolean(false)
  @Volatile private var timedOut = false
  @Volatile var released = false
    private set

  fun capability(): VisionCapability {
    if (closed.get()) return unavailable()
    return try {
      executor.submit<VisionCapability> { if (closed.get()) unavailable() else engine.capability() }
        .get(timeoutMs, TimeUnit.MILLISECONDS)
    } catch (_: TimeoutException) { timedOut = true; close(); unavailable() }
      catch (_: Exception) { unavailable() }
  }

  fun analyze(input: VisionInput): VisionResult {
    VisionInputValidator.validate(input)
    val started = System.nanoTime()
    if (closed.get()) return safe(input, if (timedOut) "timeout" else "processing_error", 0)
    return try {
      val raw = executor.submit<VisionResult> {
        if (closed.get()) safe(input, "processing_error", 0) else engine.analyze(input)
      }.get(timeoutMs, TimeUnit.MILLISECONDS)
      if (closed.get()) safe(input, "processing_error", elapsed(started))
      else VisionResultValidator.validate(input, raw.copy(durationMs = elapsed(started)))
    } catch (_: TimeoutException) {
      timedOut = true
      close()
      safe(input, "timeout", elapsed(started))
    } catch (_: InterruptedException) {
      Thread.currentThread().interrupt()
      close()
      safe(input, "processing_error", elapsed(started))
    } catch (_: Throwable) { safe(input, "processing_error", elapsed(started)) }
  }

  private fun unavailable() = VisionCapability(false, "unavailable", supportsBaselineComparison = false,
    supportsGroupCandidates = false, reason = if (timedOut) "timeout_requires_restart" else "runtime_unavailable")

  private fun safe(input: VisionInput, reason: String, duration: Long) = VisionResult(
    requestId = input.requestId, capabilityTier = "unavailable", durationMs = duration,
    quality = QualityObservation("unable", listOf(reason)), count = CountObservation.Unable(reason),
    appearance = AppearanceObservation.Unable(reason))

  private fun elapsed(start: Long) = ((System.nanoTime() - start) / 1_000_000).coerceIn(0, 60000)

  override fun close() {
    if (!closed.compareAndSet(false, true)) return
    // Native calls may ignore interruption. Do not free the model until the call returns.
    executor.execute { try { engine.close() } finally { released = true } }
    executor.shutdown()
  }
}
