package expo.modules.medicationvision.core

import kotlin.math.abs

internal class VisionContractException(message: String) : IllegalArgumentException(message)

internal object VisionInputValidator {
  private const val MAX_ID_LENGTH = 128

  fun validate(input: VisionInput): VisionInput {
    validateId(input.requestId, "requestId")
    requireContract(input.mode in setOf("baseline", "per_item", "group"), "Unsupported mode")
    validateImage(input.currentImage, "currentImage")
    if (input.mode == "baseline") {
      requireContract(input.candidates.isEmpty(), "baseline requires no candidates")
    } else if (input.mode == "per_item") {
      requireContract(input.candidates.size == 1, "per_item requires exactly one candidate")
    } else {
      requireContract(input.candidates.size in 2..8, "group requires 2 to 8 candidates")
    }

    val candidateIds = mutableSetOf<String>()
    val appearanceIds = mutableSetOf<String>()
    input.candidates.forEachIndexed { index, candidate ->
      validateId(candidate.localCandidateId, "candidates[$index].localCandidateId")
      validateId(candidate.baselineVersionId, "candidates[$index].baselineVersionId")
      requireContract(candidateIds.add(candidate.localCandidateId), "localCandidateId values must be unique")
      requireContract(appearanceIds.add(candidate.baselineVersionId), "baselineVersionId values must be unique")
      requireContract(candidate.references.size == 2, "Each candidate requires exactly front/back references")
      val views = mutableSetOf<String>()
      candidate.references.forEachIndexed { referenceIndex, reference ->
        validateImage(
          LocalImage(reference.photoEvidenceId, reference.localUri),
          "candidates[$index].references[$referenceIndex]"
        )
        requireContract(reference.view in setOf("front", "back"), "Unsupported reference view")
        requireContract(views.add(reference.view), "Reference views must be unique")
      }
      requireContract("front" in views && "back" in views, "Front and back references are required")
      requireContract(candidate.references.map { it.photoEvidenceId }.distinct().size == 2 && candidate.references.map { it.localUri }.distinct().size == 2, "Front/back must be different photos")
    }
    return input
  }

  private fun validateImage(image: LocalImage, path: String) {
    validateId(image.photoEvidenceId, "$path.photoEvidenceId")
    requireContract(
      image.localUri.startsWith("file://") || image.localUri.startsWith("content://"),
      "$path.localUri must be local"
    )
    requireContract(image.localUri.length <= 4_096, "$path.localUri is too long")
    requireContract(image.localUri.none { it.isISOControl() }, "URI contains controls")
  }

  private fun validateId(value: String, path: String) {
    requireContract(value.isNotBlank() && value.length <= MAX_ID_LENGTH, "$path is invalid")
    requireContract(value.none { it.isISOControl() }, "$path contains control characters")
  }

  private fun requireContract(condition: Boolean, message: String) {
    if (!condition) throw VisionContractException(message)
  }
}

internal object VisionResultValidator {
  private val qualityStatuses = setOf("acceptable", "unable")
  private val qualityIssues = setOf(
    "blur",
    "too_dark",
    "glare",
    "low_contrast",
    "background_noise",
    "overlap",
    "unsupported_image",
    "processing_error",
    "timeout"
  )
  private val appearanceReasons = setOf(
    "quality_unacceptable",
    "model_unavailable",
    "thresholds_not_approved",
    "group_not_supported",
    "ambiguous_candidates",
    "reference_inconsistent",
    "invalid_output",
    "processing_error",
    "timeout"
  )

  fun validate(input: VisionInput, result: VisionResult): VisionResult {
    requireValid(result.requestId == input.requestId, "Result requestId mismatch")
    requireValid(result.capabilityTier in setOf("full", "count_only", "unavailable"), "Invalid capability tier")
    requireValid(result.durationMs in 0..60_000, "Invalid duration")
    requireValid(result.quality.status in qualityStatuses, "Invalid quality status")
    requireValid(result.quality.issues.all { it in qualityIssues }, "Invalid quality issue")
    if (result.quality.status == "acceptable") {
      requireValid(result.quality.issues.isEmpty(), "Acceptable quality cannot have issues")
    } else {
      requireValid(result.quality.issues.isNotEmpty(), "Unable quality requires issues")
    }

    when (val count = result.count) {
      is CountObservation.Counted -> {
        requireValid(count.detectedObjectCount in 0..64, "Invalid object count")
        requireValid(count.boxes.size == count.detectedObjectCount, "Object count and boxes differ")
        count.boxes.forEach(::validateBox)
      }
      is CountObservation.Unable -> requireValid(
        count.reason in qualityIssues + setOf("count_model_unavailable", "invalid_output"),
        "Invalid count reason"
      )
    }

    val candidateMap = input.candidates.associate { it.localCandidateId to it.baselineVersionId }
    when (val appearance = result.appearance) {
      is AppearanceObservation.Unable -> requireValid(
        appearance.reason in appearanceReasons,
        "Invalid appearance reason"
      )
      is AppearanceObservation.Assessed -> {
        requireValid(result.capabilityTier == "full", "Appearance assessment requires full capability")
        requireValid(appearance.candidates.isNotEmpty(), "Appearance candidates cannot be empty")
        requireValid(
          appearance.candidates.map { it.localCandidateId }.distinct().size == appearance.candidates.size,
          "Appearance candidates must be unique"
        )
        appearance.candidates.forEach { candidate ->
          requireValid(
            candidateMap[candidate.localCandidateId] == candidate.baselineVersionId,
            "Appearance candidate mapping mismatch"
          )
          when (candidate) {
            is CandidateAppearance.Observed -> {
              requireValid(
                candidate.outcome in setOf("no_anomaly_signal", "suspected_change"),
                "Invalid appearance outcome"
              )
              requireValid(candidate.distance.isFinite() && candidate.distance in 0.0..2.0, "Invalid distance")
            }
            is CandidateAppearance.Unable -> requireValid(
              candidate.reason in appearanceReasons,
              "Invalid candidate reason"
            )
          }
        }
      }
    }
    return result
  }

  private fun validateBox(box: NormalizedBox) {
    val values = listOf(box.x, box.y, box.width, box.height)
    requireValid(values.all { it.isFinite() }, "Box values must be finite")
    requireValid(box.x in 0.0..1.0 && box.y in 0.0..1.0, "Box origin is outside bounds")
    requireValid(box.width > 0.0 && box.width <= 1.0, "Box width is invalid")
    requireValid(box.height > 0.0 && box.height <= 1.0, "Box height is invalid")
    requireValid(box.x + box.width <= 1.0 || abs(box.x + box.width - 1.0) <= 1e-9, "Box exceeds width")
    requireValid(box.y + box.height <= 1.0 || abs(box.y + box.height - 1.0) <= 1e-9, "Box exceeds height")
  }

  private fun requireValid(condition: Boolean, message: String) {
    if (!condition) throw VisionContractException(message)
  }
}
