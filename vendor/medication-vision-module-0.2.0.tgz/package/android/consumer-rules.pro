# Keep only the Expo module entry point by name. LiteRT publishes its own consumer rules.
-keep class expo.modules.medicationvision.MedicationVisionModule { *; }
# LiteRT is called through a Java reflection boundary until the Expo Kotlin toolchain catches up.
-keep class com.google.ai.edge.litert.** { *; }
