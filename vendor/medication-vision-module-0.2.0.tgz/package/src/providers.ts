import {
  MEDICATION_VISION_RUNTIME_VERSION,
  MEDICATION_VISION_TIMEOUT_MS,
  type ClosedSetVisionResult,
  type NativeMedicationVisionBridge,
  type VisionAnalysisInput,
  type VisionInferenceProvider,
  type VisionProviderCapability,
} from './MedicationVision.types';
import { getNativeMedicationVisionBridge } from './MedicationVisionModule';
import {
  makeUnableResult,
  validateVisionAnalysisInput,
  validateVisionCapability,
  validateVisionResult,
} from './validation';

export class OnDeviceVisionProvider implements VisionInferenceProvider {
  private generation = 0;
  constructor(
    private readonly bridgeFactory: () => NativeMedicationVisionBridge = getNativeMedicationVisionBridge
  ) {}

  async getCapability(): Promise<VisionProviderCapability> {
    try {
      return validateVisionCapability(
        await this.deadline(this.bridgeFactory().getCapabilityAsync())
      );
    } catch {
      return {
        available: false,
        providerKind: 'on_device',
        tier: 'unavailable',
        runtimeVersion: MEDICATION_VISION_RUNTIME_VERSION,
        supportsBaselineComparison: false,
        supportsGroupCandidates: false,
        reason: 'runtime_unavailable',
      };
    }
  }

  async analyze(input: VisionAnalysisInput): Promise<ClosedSetVisionResult> {
    const validatedInput = validateVisionAnalysisInput(input);
    const generation = this.generation;
    const started = Date.now();
    try {
      const rawResult = await this.deadline(
        this.bridgeFactory().analyzeAsync(JSON.stringify(validatedInput))
      );
      if (generation !== this.generation)
        return makeUnableResult(validatedInput, 'on_device', 'processing_error');
      return validateVisionResult(rawResult, validatedInput);
    } catch (error) {
      return makeUnableResult(
        validatedInput,
        'on_device',
        error instanceof Error && error.message === 'vision_timeout'
          ? 'timeout'
          : 'processing_error',
        Math.min(60000, Date.now() - started)
      );
    }
  }

  async cancel(): Promise<void> {
    this.generation += 1;
    try {
      await this.bridgeFactory().cancelAsync?.();
    } catch {
      /* Native unavailable. */
    }
  }

  private async deadline<T>(operation: Promise<T>): Promise<T> {
    let timer: ReturnType<typeof setTimeout> | undefined;
    try {
      return await Promise.race([
        operation,
        new Promise<never>((_, reject) => {
          timer = setTimeout(() => {
            this.cancel().catch(() => undefined);
            reject(new Error('vision_timeout'));
          }, MEDICATION_VISION_TIMEOUT_MS);
        }),
      ]);
    } finally {
      if (timer) clearTimeout(timer);
    }
  }
}

/**
 * Deliberately contains no endpoint, credential, fetch call, or retry behavior.
 * Enabling a remote provider requires a separate build variant and privacy review.
 */
export class DisabledRemoteVisionProvider implements VisionInferenceProvider {
  async cancel(): Promise<void> {
    /* No transport exists. */
  }
  async getCapability(): Promise<VisionProviderCapability> {
    return {
      available: false,
      providerKind: 'remote_api',
      tier: 'unavailable',
      runtimeVersion: MEDICATION_VISION_RUNTIME_VERSION,
      supportsBaselineComparison: false,
      supportsGroupCandidates: false,
      reason: 'remote_disabled',
    };
  }

  async analyze(input: VisionAnalysisInput): Promise<ClosedSetVisionResult> {
    return makeUnableResult(validateVisionAnalysisInput(input), 'remote_api', 'model_unavailable');
  }
}
