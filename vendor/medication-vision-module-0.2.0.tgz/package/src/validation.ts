import {
  MEDICATION_VISION_RUNTIME_VERSION,
  MEDICATION_VISION_SCHEMA_VERSION,
  type AppearanceCandidateOutcome,
  type AppearanceUnableReason,
  type ClosedSetVisionResult,
  type NormalizedVisionBox,
  type VisionAnalysisInput,
  type VisionCandidate,
  type VisionCountObservation,
  type VisionCountUnableReason,
  type VisionProviderCapability,
  type VisionQualityIssue,
  type VisionQualityObservation,
} from './MedicationVision.types';

const MAX_ID_LENGTH = 128;
const MAX_GROUP_CANDIDATES = 8;
const MAX_BOXES = 64;
const EPSILON = 1e-9;

export class VisionContractError extends Error {
  constructor(
    readonly code: 'INVALID_INPUT' | 'INVALID_CAPABILITY' | 'INVALID_RESULT',
    message: string
  ) {
    super(message);
    this.name = 'VisionContractError';
  }
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function assertRecord(value: unknown, path: string, code: VisionContractError['code']) {
  if (!isRecord(value)) throw new VisionContractError(code, `${path} must be an object`);
  return value;
}

function assertString(
  value: unknown,
  path: string,
  code: VisionContractError['code'],
  allowed?: readonly string[]
): string {
  if (
    typeof value !== 'string' ||
    !value.trim() ||
    value.length > MAX_ID_LENGTH ||
    /[\u0000-\u001f\u007f-\u009f]/u.test(value)
  ) {
    throw new VisionContractError(code, `${path} must be a non-empty bounded string`);
  }
  if (allowed && !allowed.includes(value)) {
    throw new VisionContractError(code, `${path} has an unsupported value`);
  }
  return value;
}

function assertFiniteNumber(
  value: unknown,
  path: string,
  code: VisionContractError['code'],
  minimum: number,
  maximum: number
): number {
  if (typeof value !== 'number' || !Number.isFinite(value) || value < minimum || value > maximum) {
    throw new VisionContractError(
      code,
      `${path} must be finite and between ${minimum} and ${maximum}`
    );
  }
  return value;
}

function validateLocalUri(value: unknown, path: string): string {
  if (
    typeof value !== 'string' ||
    value.length > 4096 ||
    /[\u0000-\u001f\u007f-\u009f]/u.test(value)
  ) {
    throw new VisionContractError('INVALID_INPUT', `${path} must be a bounded local URI`);
  }
  const uri = value;
  if (!uri.startsWith('file://') && !uri.startsWith('content://')) {
    throw new VisionContractError(
      'INVALID_INPUT',
      `${path} must be a local file:// or content:// URI`
    );
  }
  return uri;
}

function validateCandidate(value: unknown, index: number): VisionCandidate {
  const candidate = assertRecord(value, `candidates[${index}]`, 'INVALID_INPUT');
  const references = candidate.references;
  if (!Array.isArray(references) || references.length !== 2) {
    throw new VisionContractError(
      'INVALID_INPUT',
      `candidates[${index}].references must contain exactly one front and one back image`
    );
  }

  const parsedReferences = references.map((reference, referenceIndex) => {
    const item = assertRecord(
      reference,
      `candidates[${index}].references[${referenceIndex}]`,
      'INVALID_INPUT'
    );
    return {
      photoEvidenceId: assertString(
        item.photoEvidenceId,
        `candidates[${index}].references[${referenceIndex}].photoEvidenceId`,
        'INVALID_INPUT'
      ),
      localUri: validateLocalUri(
        item.localUri,
        `candidates[${index}].references[${referenceIndex}].localUri`
      ),
      view: assertString(
        item.view,
        `candidates[${index}].references[${referenceIndex}].view`,
        'INVALID_INPUT',
        ['front', 'back']
      ) as 'front' | 'back',
    };
  });

  const views = new Set(parsedReferences.map((reference) => reference.view));
  if (
    new Set(parsedReferences.map((r) => r.photoEvidenceId)).size !== 2 ||
    new Set(parsedReferences.map((r) => r.localUri)).size !== 2
  ) {
    throw new VisionContractError('INVALID_INPUT', 'Front and back must be different photos');
  }
  if (!views.has('front') || !views.has('back') || views.size !== parsedReferences.length) {
    throw new VisionContractError(
      'INVALID_INPUT',
      `candidates[${index}].references must have unique views including front and back`
    );
  }

  return {
    localCandidateId: assertString(
      candidate.localCandidateId,
      `candidates[${index}].localCandidateId`,
      'INVALID_INPUT'
    ),
    baselineVersionId: assertString(
      candidate.baselineVersionId,
      `candidates[${index}].baselineVersionId`,
      'INVALID_INPUT'
    ),
    references: parsedReferences as VisionCandidate['references'],
  };
}

export function validateVisionAnalysisInput(value: unknown): VisionAnalysisInput {
  const input = assertRecord(value, 'input', 'INVALID_INPUT');
  if (input.schemaVersion !== MEDICATION_VISION_SCHEMA_VERSION) {
    throw new VisionContractError('INVALID_INPUT', 'input.schemaVersion is unsupported');
  }
  const mode = assertString(input.mode, 'input.mode', 'INVALID_INPUT', [
    'baseline',
    'per_item',
    'group',
  ]) as VisionAnalysisInput['mode'];
  const currentImage = assertRecord(input.currentImage, 'input.currentImage', 'INVALID_INPUT');
  if (!Array.isArray(input.candidates)) {
    throw new VisionContractError('INVALID_INPUT', 'input.candidates must be an array');
  }
  if (mode === 'baseline' && input.candidates.length !== 0) {
    throw new VisionContractError('INVALID_INPUT', 'baseline mode cannot have candidates');
  }
  if (mode === 'per_item' && input.candidates.length !== 1) {
    throw new VisionContractError(
      'INVALID_INPUT',
      'per_item mode requires exactly one explicit candidate'
    );
  }
  if (
    mode === 'group' &&
    (input.candidates.length < 2 || input.candidates.length > MAX_GROUP_CANDIDATES)
  ) {
    throw new VisionContractError(
      'INVALID_INPUT',
      'group mode requires 2 to 8 explicit candidates'
    );
  }

  const candidates = input.candidates.map(validateCandidate);
  const candidateIds = candidates.map((candidate) => candidate.localCandidateId);
  if (new Set(candidateIds).size !== candidateIds.length) {
    throw new VisionContractError(
      'INVALID_INPUT',
      'localCandidateId values must be unique within a request'
    );
  }
  const appearanceIds = candidates.map((candidate) => candidate.baselineVersionId);
  if (new Set(appearanceIds).size !== appearanceIds.length) {
    throw new VisionContractError(
      'INVALID_INPUT',
      'baselineVersionId values must map to one candidate'
    );
  }

  return {
    schemaVersion: MEDICATION_VISION_SCHEMA_VERSION,
    requestId: assertString(input.requestId, 'input.requestId', 'INVALID_INPUT'),
    mode,
    currentImage: {
      photoEvidenceId: assertString(
        currentImage.photoEvidenceId,
        'input.currentImage.photoEvidenceId',
        'INVALID_INPUT'
      ),
      localUri: validateLocalUri(currentImage.localUri, 'input.currentImage.localUri'),
    },
    candidates,
  };
}

export function validateNormalizedBox(value: unknown, path = 'box'): NormalizedVisionBox {
  const box = assertRecord(value, path, 'INVALID_RESULT');
  const x = assertFiniteNumber(box.x, `${path}.x`, 'INVALID_RESULT', 0, 1);
  const y = assertFiniteNumber(box.y, `${path}.y`, 'INVALID_RESULT', 0, 1);
  const width = assertFiniteNumber(box.width, `${path}.width`, 'INVALID_RESULT', Number.EPSILON, 1);
  const height = assertFiniteNumber(
    box.height,
    `${path}.height`,
    'INVALID_RESULT',
    Number.EPSILON,
    1
  );
  if (x + width > 1 + EPSILON || y + height > 1 + EPSILON) {
    throw new VisionContractError(
      'INVALID_RESULT',
      `${path} must remain inside normalized image bounds`
    );
  }
  return { x, y, width, height };
}

function validateQuality(value: unknown): VisionQualityObservation {
  const quality = assertRecord(value, 'result.quality', 'INVALID_RESULT');
  const status = assertString(quality.status, 'result.quality.status', 'INVALID_RESULT', [
    'acceptable',
    'unable',
  ]);
  if (!Array.isArray(quality.issues)) {
    throw new VisionContractError('INVALID_RESULT', 'result.quality.issues must be an array');
  }
  const allowedIssues = [
    'blur',
    'too_dark',
    'glare',
    'low_contrast',
    'background_noise',
    'overlap',
    'unsupported_image',
    'processing_error',
    'timeout',
  ] as const;
  const issues = quality.issues.map((issue, index) =>
    assertString(issue, `result.quality.issues[${index}]`, 'INVALID_RESULT', allowedIssues)
  ) as VisionQualityIssue[];
  if (status === 'acceptable') {
    if (issues.length !== 0) {
      throw new VisionContractError('INVALID_RESULT', 'acceptable quality cannot contain issues');
    }
    return { status: 'acceptable', issues: [] };
  }
  if (issues.length === 0) {
    throw new VisionContractError('INVALID_RESULT', 'unable quality requires at least one issue');
  }
  return { status: 'unable', issues };
}

function validateCount(value: unknown): VisionCountObservation {
  const count = assertRecord(value, 'result.count', 'INVALID_RESULT');
  const status = assertString(count.status, 'result.count.status', 'INVALID_RESULT', [
    'counted',
    'unable',
  ]);
  if (status === 'unable') {
    const reason = assertString(count.reason, 'result.count.reason', 'INVALID_RESULT', [
      'blur',
      'too_dark',
      'glare',
      'low_contrast',
      'background_noise',
      'overlap',
      'unsupported_image',
      'processing_error',
      'timeout',
      'count_model_unavailable',
      'invalid_output',
    ]) as VisionCountUnableReason;
    return { status: 'unable', reason };
  }

  const detectedObjectCount = assertFiniteNumber(
    count.detectedObjectCount,
    'result.count.detectedObjectCount',
    'INVALID_RESULT',
    0,
    MAX_BOXES
  );
  if (!Number.isInteger(detectedObjectCount)) {
    throw new VisionContractError('INVALID_RESULT', 'detectedObjectCount must be an integer');
  }
  if (!Array.isArray(count.boxes) || count.boxes.length !== detectedObjectCount) {
    throw new VisionContractError(
      'INVALID_RESULT',
      'boxes must contain one normalized box per detected object'
    );
  }
  return {
    status: 'counted',
    detectedObjectCount,
    boxes: count.boxes.map((box, index) =>
      validateNormalizedBox(box, `result.count.boxes[${index}]`)
    ),
  };
}

function validateAppearanceCandidate(
  value: unknown,
  index: number,
  candidateMap: Map<string, string>
): AppearanceCandidateOutcome {
  const item = assertRecord(value, `result.appearance.candidates[${index}]`, 'INVALID_RESULT');
  const localCandidateId = assertString(
    item.localCandidateId,
    `result.appearance.candidates[${index}].localCandidateId`,
    'INVALID_RESULT'
  );
  const baselineVersionId = assertString(
    item.baselineVersionId,
    `result.appearance.candidates[${index}].baselineVersionId`,
    'INVALID_RESULT'
  );
  if (candidateMap.get(localCandidateId) !== baselineVersionId) {
    throw new VisionContractError(
      'INVALID_RESULT',
      'appearance result does not match the explicit candidate mapping'
    );
  }
  const outcome = assertString(
    item.outcome,
    `result.appearance.candidates[${index}].outcome`,
    'INVALID_RESULT',
    ['no_anomaly_signal', 'suspected_change', 'unable']
  );
  if (outcome === 'unable') {
    const reason = assertString(
      item.reason,
      `result.appearance.candidates[${index}].reason`,
      'INVALID_RESULT',
      [
        'quality_unacceptable',
        'model_unavailable',
        'thresholds_not_approved',
        'group_not_supported',
        'ambiguous_candidates',
        'reference_inconsistent',
        'invalid_output',
        'processing_error',
        'timeout',
      ]
    ) as AppearanceUnableReason;
    return { localCandidateId, baselineVersionId, outcome: 'unable', reason };
  }
  return {
    localCandidateId,
    baselineVersionId,
    outcome: outcome as 'no_anomaly_signal' | 'suspected_change',
    distance: assertFiniteNumber(
      item.distance,
      `result.appearance.candidates[${index}].distance`,
      'INVALID_RESULT',
      0,
      2
    ),
  };
}

export function validateVisionResult(
  value: unknown,
  input: VisionAnalysisInput
): ClosedSetVisionResult {
  const result = assertRecord(value, 'result', 'INVALID_RESULT');
  if (
    result.schemaVersion !== MEDICATION_VISION_SCHEMA_VERSION ||
    result.requestId !== input.requestId
  ) {
    throw new VisionContractError(
      'INVALID_RESULT',
      'result schema or requestId does not match the request'
    );
  }
  const providerKind = assertString(result.providerKind, 'result.providerKind', 'INVALID_RESULT', [
    'on_device',
    'remote_api',
  ]) as 'on_device' | 'remote_api';
  const capabilityTier = assertString(
    result.capabilityTier,
    'result.capabilityTier',
    'INVALID_RESULT',
    ['full', 'count_only', 'unavailable']
  ) as 'full' | 'count_only' | 'unavailable';
  const appearance = assertRecord(result.appearance, 'result.appearance', 'INVALID_RESULT');
  const appearanceStatus = assertString(
    appearance.status,
    'result.appearance.status',
    'INVALID_RESULT',
    ['assessed', 'unable']
  );
  const candidateMap = new Map(
    input.candidates.map((candidate) => [candidate.localCandidateId, candidate.baselineVersionId])
  );
  let parsedAppearance: ClosedSetVisionResult['appearance'];
  if (appearanceStatus === 'assessed') {
    if (
      capabilityTier !== 'full' ||
      !Array.isArray(appearance.candidates) ||
      appearance.candidates.length === 0
    ) {
      throw new VisionContractError(
        'INVALID_RESULT',
        'assessed appearance requires full capability and candidates'
      );
    }
    const candidates = appearance.candidates.map((candidate, index) =>
      validateAppearanceCandidate(candidate, index, candidateMap)
    );
    if (
      new Set(candidates.map((candidate) => candidate.localCandidateId)).size !== candidates.length
    ) {
      throw new VisionContractError('INVALID_RESULT', 'appearance candidates must be unique');
    }
    parsedAppearance = { status: 'assessed', candidates };
  } else {
    const reason = assertString(appearance.reason, 'result.appearance.reason', 'INVALID_RESULT', [
      'quality_unacceptable',
      'model_unavailable',
      'thresholds_not_approved',
      'group_not_supported',
      'ambiguous_candidates',
      'reference_inconsistent',
      'invalid_output',
      'processing_error',
      'timeout',
    ]) as AppearanceUnableReason;
    parsedAppearance = { status: 'unable', reason };
  }

  const quality = validateQuality(result.quality);
  const count = validateCount(result.count);
  if (
    parsedAppearance.status === 'assessed' &&
    (quality.status !== 'acceptable' ||
      count.status !== 'counted' ||
      input.mode !== 'per_item' ||
      parsedAppearance.candidates.length !== input.candidates.length)
  ) {
    throw new VisionContractError(
      'INVALID_RESULT',
      'Appearance requires valid per-item quality and count'
    );
  }
  let objects: ClosedSetVisionResult['objects'];
  if (result.objects !== undefined) {
    if (!Array.isArray(result.objects) || result.objects.length > 8)
      throw new VisionContractError('INVALID_RESULT', 'Invalid objects');
    objects = result.objects.map((raw, index) => {
      const item = assertRecord(raw, 'object', 'INVALID_RESULT');
      if (
        item.objectIndex !== index ||
        count.status !== 'counted' ||
        parsedAppearance.status !== 'assessed'
      )
        throw new VisionContractError('INVALID_RESULT', 'Invalid object mapping');
      const box = validateNormalizedBox(item.box);
      if (JSON.stringify(box) !== JSON.stringify(count.boxes[index]))
        throw new VisionContractError('INVALID_RESULT', 'Object box mismatch');
      return {
        objectIndex: index,
        box,
        observation: validateAppearanceCandidate(item.observation, index, candidateMap),
      };
    });
    if (
      parsedAppearance.status === 'assessed' &&
      count.status === 'counted' &&
      objects.length !== count.detectedObjectCount
    )
      throw new VisionContractError('INVALID_RESULT', 'Incomplete object observations');
  }

  return {
    schemaVersion: MEDICATION_VISION_SCHEMA_VERSION,
    requestId: input.requestId,
    providerKind,
    capabilityTier,
    runtimeVersion: assertString(result.runtimeVersion, 'result.runtimeVersion', 'INVALID_RESULT'),
    ...(typeof result.modelVersion === 'string' && result.modelVersion.length > 0
      ? { modelVersion: result.modelVersion }
      : {}),
    durationMs: assertFiniteNumber(
      result.durationMs,
      'result.durationMs',
      'INVALID_RESULT',
      0,
      60_000
    ),
    quality,
    count,
    appearance: parsedAppearance,
    ...(objects ? { objects } : {}),
  };
}

export function validateVisionCapability(value: unknown): VisionProviderCapability {
  const capability = assertRecord(value, 'capability', 'INVALID_CAPABILITY');
  const providerKind = assertString(
    capability.providerKind,
    'capability.providerKind',
    'INVALID_CAPABILITY',
    ['on_device', 'remote_api']
  ) as 'on_device' | 'remote_api';
  const tier = assertString(capability.tier, 'capability.tier', 'INVALID_CAPABILITY', [
    'full',
    'count_only',
    'unavailable',
  ]) as 'full' | 'count_only' | 'unavailable';
  const reason = assertString(capability.reason, 'capability.reason', 'INVALID_CAPABILITY', [
    'ready',
    'model_manifest_missing',
    'model_manifest_invalid',
    'model_missing',
    'model_hash_mismatch',
    'tensor_contract_mismatch',
    'thresholds_not_approved',
    'runtime_unavailable',
    'remote_disabled',
    'timeout_requires_restart',
  ]) as VisionProviderCapability['reason'];
  if (typeof capability.available !== 'boolean') {
    throw new VisionContractError('INVALID_CAPABILITY', 'capability.available must be boolean');
  }
  if (capability.available !== (tier !== 'unavailable')) {
    throw new VisionContractError(
      'INVALID_CAPABILITY',
      'capability.available and tier are inconsistent'
    );
  }
  if (
    typeof capability.supportsBaselineComparison !== 'boolean' ||
    typeof capability.supportsGroupCandidates !== 'boolean'
  ) {
    throw new VisionContractError('INVALID_CAPABILITY', 'capability support flags must be boolean');
  }
  if (tier !== 'full' && capability.supportsBaselineComparison) {
    throw new VisionContractError(
      'INVALID_CAPABILITY',
      'baseline comparison requires full capability'
    );
  }

  return {
    available: capability.available,
    providerKind,
    tier,
    runtimeVersion: assertString(
      capability.runtimeVersion,
      'capability.runtimeVersion',
      'INVALID_CAPABILITY'
    ),
    ...(typeof capability.modelVersion === 'string' && capability.modelVersion.length > 0
      ? { modelVersion: capability.modelVersion }
      : {}),
    supportsBaselineComparison: capability.supportsBaselineComparison,
    supportsGroupCandidates: capability.supportsGroupCandidates,
    reason,
  };
}

export function makeUnableResult(
  input: VisionAnalysisInput,
  providerKind: 'on_device' | 'remote_api',
  reason: 'model_unavailable' | 'processing_error' | 'timeout',
  durationMs = 0
): ClosedSetVisionResult {
  const qualityIssue = reason === 'timeout' ? 'timeout' : 'processing_error';
  return {
    schemaVersion: MEDICATION_VISION_SCHEMA_VERSION,
    requestId: input.requestId,
    providerKind,
    capabilityTier: 'unavailable',
    runtimeVersion: MEDICATION_VISION_RUNTIME_VERSION,
    durationMs,
    quality: { status: 'unable', issues: [qualityIssue] },
    count: { status: 'unable', reason: qualityIssue },
    appearance: { status: 'unable', reason },
  };
}
