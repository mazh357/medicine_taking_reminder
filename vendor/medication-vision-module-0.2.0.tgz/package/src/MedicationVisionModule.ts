import { NativeModule, requireNativeModule } from 'expo';

import type { NativeMedicationVisionBridge } from './MedicationVision.types';

declare class MedicationVisionNativeModule
  extends NativeModule<Record<string, never>>
  implements NativeMedicationVisionBridge
{
  getCapabilityAsync(): Promise<unknown>;
  analyzeAsync(inputJson: string): Promise<unknown>;
}

/** Lazily resolves the module so contract tests can run without a native host. */
export function getNativeMedicationVisionBridge(): NativeMedicationVisionBridge {
  return requireNativeModule<MedicationVisionNativeModule>('MedicationVision');
}
