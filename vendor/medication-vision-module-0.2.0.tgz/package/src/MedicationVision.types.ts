export const MEDICATION_VISION_SCHEMA_VERSION = '1' as const;
export const MEDICATION_VISION_RUNTIME_VERSION = '2.2.0' as const;
export const MEDICATION_VISION_TIMEOUT_MS = 3_000 as const;

export type VisionProviderKind = 'on_device' | 'remote_api';
export type VisionCapabilityTier = 'full' | 'count_only' | 'unavailable';
export type VisionMode = 'baseline' | 'per_item' | 'group';

export type VisionCapabilityReason =
  | 'ready'
  | 'model_manifest_missing'
  | 'model_manifest_invalid'
  | 'model_missing'
  | 'model_hash_mismatch'
  | 'tensor_contract_mismatch'
  | 'thresholds_not_approved'
  | 'runtime_unavailable'
  | 'remote_disabled'
  | 'timeout_requires_restart';

export type VisionProviderCapability = {
  available: boolean;
  providerKind: VisionProviderKind;
  tier: VisionCapabilityTier;
  runtimeVersion: string;
  modelVersion?: string;
  supportsBaselineComparison: boolean;
  supportsGroupCandidates: boolean;
  reason: VisionCapabilityReason;
};

export type LocalVisionImage = {
  photoEvidenceId: string;
  /** A local file:// or content:// URI. Network and data URIs are rejected. */
  localUri: string;
};

export type BaselineView = 'front' | 'back';

export type VisionReferenceImage = LocalVisionImage & {
  view: BaselineView;
};

/**
 * localCandidateId is an opaque, request-scoped identifier. The module never needs a
 * medication name, prescription, disease, inventory value, or patient identity.
 */
export type VisionCandidate = {
  localCandidateId: string;
  baselineVersionId: string;
  /** Exactly one front image and one back image. */
  references: [VisionReferenceImage, VisionReferenceImage];
};

export type VisionAnalysisInput = {
  schemaVersion: typeof MEDICATION_VISION_SCHEMA_VERSION;
  requestId: string;
  mode: VisionMode;
  currentImage: LocalVisionImage;
  candidates: VisionCandidate[];
};

export type NormalizedVisionBox = {
  x: number;
  y: number;
  width: number;
  height: number;
};

export type VisionQualityIssue =
  | 'blur'
  | 'too_dark'
  | 'glare'
  | 'low_contrast'
  | 'background_noise'
  | 'overlap'
  | 'unsupported_image'
  | 'processing_error'
  | 'timeout';

export type VisionQualityObservation =
  { status: 'acceptable'; issues: [] } | { status: 'unable'; issues: VisionQualityIssue[] };

export type VisionCountUnableReason =
  VisionQualityIssue | 'count_model_unavailable' | 'invalid_output';

export type VisionCountObservation =
  | {
      status: 'counted';
      detectedObjectCount: number;
      boxes: NormalizedVisionBox[];
    }
  | {
      status: 'unable';
      reason: VisionCountUnableReason;
    };

export type AppearanceUnableReason =
  | 'quality_unacceptable'
  | 'model_unavailable'
  | 'thresholds_not_approved'
  | 'group_not_supported'
  | 'ambiguous_candidates'
  | 'reference_inconsistent'
  | 'invalid_output'
  | 'processing_error'
  | 'timeout';

export type AppearanceCandidateOutcome =
  | {
      localCandidateId: string;
      baselineVersionId: string;
      outcome: 'no_anomaly_signal' | 'suspected_change';
      /** Cosine distance. It is an observation, never an identity probability. */
      distance: number;
    }
  | {
      localCandidateId: string;
      baselineVersionId: string;
      outcome: 'unable';
      reason: AppearanceUnableReason;
    };

export type VisionAppearanceObservation =
  | {
      status: 'assessed';
      candidates: AppearanceCandidateOutcome[];
    }
  | {
      status: 'unable';
      reason: AppearanceUnableReason;
    };

export type ClosedSetVisionResult = {
  schemaVersion: typeof MEDICATION_VISION_SCHEMA_VERSION;
  requestId: string;
  providerKind: VisionProviderKind;
  capabilityTier: VisionCapabilityTier;
  runtimeVersion: string;
  modelVersion?: string;
  durationMs: number;
  quality: VisionQualityObservation;
  count: VisionCountObservation;
  appearance: VisionAppearanceObservation;
  objects?: {
    objectIndex: number;
    box: NormalizedVisionBox;
    observation: AppearanceCandidateOutcome;
  }[];
};

export interface VisionInferenceProvider {
  getCapability(): Promise<VisionProviderCapability>;
  analyze(input: VisionAnalysisInput): Promise<ClosedSetVisionResult>;
  cancel(): Promise<void>;
}

export interface NativeMedicationVisionBridge {
  getCapabilityAsync(): Promise<unknown>;
  analyzeAsync(inputJson: string): Promise<unknown>;
  cancelAsync?(): Promise<void>;
}
