# 用药照片闭集视觉模块

版本：`0.2.0`

状态：主 App 独立实验入口已接入代码｜外观阈值未批准｜不得用于真实患者数据

更新日期：`2026-08-31`

本目录是一个独立的 Expo Android 原生模块，用于验证“用户个人外观基线范围内”的照片画质、受控背景物体计数和外观变化观察。它不是开放式识药工具，不判断药物身份、真伪或剂量，也不会确认服药或修改库存。

## 当前完成情况

- 已建立 TypeScript 公共契约、输入/输出校验和禁用的远程 Provider。
- 已建立 Kotlin 串行执行、3 秒超时、失败隔离和安全回退。
- 已实现哑光纯色背景下的轮廓计数原型。
- 已建立 LiteRT `2.2.0` CPU 推理边界、模型清单校验、模型 SHA-256 校验和张量预检。
- 每个候选基线必须恰好包含正面、背面各一张照片。
- 逐药比较代码路径已搭建；没有经批准的模型和阈值时自动退化为 `count_only`。
- 整组输入契约已冻结，但原生分组推理尚未开放，固定返回人工回退。
- 已包含许可明确的官方 MobileNetV3-small 权重，阈值与药片任务评测尚未批准，运行时仍为 `count_only`。没有网络权限、远程端点、令牌、上传或遥测。

## 与现有 App 的隔离

本模块位于：

```text
D:\help_u_surivive\medication-vision-module
```

现有 App 位于：

```text
D:\help_u_surivive\medication-adherence-app
```

模块通过带版本的本地 npm 包接入主 App，主 App 不依赖此兄弟目录。实验入口与原服药流程隔离，整合状态、模型证据和未通过门禁见 [0.2.0 记录](docs/INTEGRATION_2026-08-31.md)。

## 安全边界

- 输入只接受本地 `file://` 或 `content://` 图片；原生层进一步限制 `file://` 必须位于宿主应用私有目录。
- 调用方应只传短期解密暂存文件，负责在调用完成、失败或退到后台时清除；模块不接触数据库密钥。
- `localCandidateId` 是单次请求使用的匿名标识，不得传药名、处方、疾病、患者身份、剂量或库存。
- 照片检测数、计划服用量和用户确认实际服用量属于不同事实；本模块只输出第一项观察。
- `no_anomaly_signal` 仅供内部策略使用，不能在界面上表达为“正确”或“识别一致”。
- 半片、破损、透明胶囊、遮挡、重叠、反光、杂乱背景或近似候选必须走人工回退。

## 公共接口

```ts
type VisionCandidate = {
  localCandidateId: string;
  baselineVersionId: string;
  references: [
    { photoEvidenceId: string; localUri: string; view: "front" | "back" },
    { photoEvidenceId: string; localUri: string; view: "front" | "back" },
  ];
};
```

完整类型见 [`src/MedicationVision.types.ts`](src/MedicationVision.types.ts)。应用层只依赖 `VisionInferenceProvider`。`OnDeviceVisionProvider` 调用 Kotlin；`DisabledRemoteVisionProvider` 永远报告不可用，且不包含任何联网实现。

## 本地检查

先进入模块目录安装依赖：

```powershell
cd D:\help_u_surivive\medication-vision-module
npm install
npm run check
```

`npm run check`依次完成 TypeScript 构建、代码规范、Node 测试和隔离检查。

Android 单元测试及 AAR 构建使用项目脚本，所有缓存和临时文件均留在 `D:\help_u_surivive\.toolchains`：

```powershell
cd D:\help_u_surivive\medication-vision-module
npm run test:android
```

依赖已缓存后可完全离线复验：

```powershell
powershell -ExecutionPolicy Bypass -File scripts\test-android.ps1 -Offline
```

本机 Maven Central 访问异常时，脚本会自动使用 D 盘现有的临时仓库配置；该地址没有写入模块 Gradle 配置，也不会成为运行时依赖。

生成的独立库位于：

```text
D:\help_u_surivive\medication-vision-module\android\build\outputs\aar\medication-vision-module-debug.aar
```

这是 Android Library，不是可直接安装的 APK。主 App 集成包的状态以其交付记录为准。

## 模型准入

权重分发与外观功能启用是两道门禁。模型来源、许可和哈希已核验；只有阈值及独立评测获得批准后才能启用外观结论，否则保持计数和人工确认。详情见 [整合记录](docs/INTEGRATION_2026-08-31.md)。

## 后续路径

实施阶段和门禁见 [`docs/IMPLEMENTATION_PATH.md`](docs/IMPLEMENTATION_PATH.md)，LiteRT 决策见 [`docs/ADR-001-litert-2.2-runtime.md`](docs/ADR-001-litert-2.2-runtime.md)，本轮证据见 [`docs/BUILD_VERIFICATION_2026-08-29.md`](docs/BUILD_VERIFICATION_2026-08-29.md)，第三方依赖和研究参考见 [`THIRD_PARTY_NOTICES.md`](THIRD_PARTY_NOTICES.md)。

本模块为私有内部试验代码，项目自身为 `UNLICENSED`；第三方组件继续遵守各自许可证。
